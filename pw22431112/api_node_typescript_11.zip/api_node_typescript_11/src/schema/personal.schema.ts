import { z } from  'zod'
const telefonoRegEx = new RegExp(
    /^([+]?[\s0-9]+)?(\d{3}|[(]?[0-9]+[)])?([-]?[\s]?[0-9])+$/
);

const nombreRegEx = new RegExp(
    /^[A-Za-z0-9/#\s]+$/
);

const direccionRegEx = new RegExp(
    /^[A-Za-z0-9/#\s]+$/
)

const estatusRegEx = new RegExp(
    /^[12]$/
)

// const idRegEx = new RegExp(
//     /^[1-9][0-9]*$/
// )

//Validaciones con Zod - construir schema
export const personalSchema = z.object({
    //nombre: z.string().min(2,"Minimo 2 caracteres").max(200,"Maximo 200 caracteres"),
    //direccion: z.string().min(2).max(300),
    //telefono: z.string().min(10).max(15),
    //estatus: z.number().int().positive()
    nombre: z.string().regex(nombreRegEx),
    direccion: z.string().regex(direccionRegEx),
    telefono: z.string().regex(telefonoRegEx),
    estatus: z .number().refine((value) => estatusRegEx.test(value.toString()))
    //estatus: z.number().int().positive().min(1).max(2,"Los valores correctos son 1 y 2")
}).refine(data => data.direccion == "TEC DE CULIACAN",{
    message: "La direccion debe ser del Tec de Culiacan",
    path:["direccion"]
}).refine(data => data.estatus <= 2,{
    message: "Los valores correctos son 1(vigente) y 2(baja)",
    path:["estatus"]
}).or(
     z.object({
         telefono: z.string().min(10).max(15)
     })
).or(
     z.object({
         id: z.number().int().positive().min(1).max(9999)
     })
)

//.or(
//     z.object({
//         direccion: z.string().min(2).max(300)
//     })
// ).or(
//     z.object({
//         nombre: z.string().min(2,"Minimo 2 caracteres").max(200,"Maximo 200 caracteres")
//     })
// ).or(
//     z.object({
//         estatus: z.number().int().positive().min(1).max(2,"Los valores correctos son 1 y 2")
//     })
//.or(
//     z.object({
//         id: z.number().int().positive().min(1).max(9999)
//     })
// )