// let mensaje = "hola JavaScript";
// console.log(mensaje);
// console.log(typeof(mensaje));

// let mensaje = 2;
// console.log(mensaje);
// console.log(typeof(mensaje));

